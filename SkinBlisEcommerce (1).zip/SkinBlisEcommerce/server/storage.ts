import { 
  products, type Product, type InsertProduct,
  orders, type Order, type InsertOrder,
  orderItems, type OrderItem, type InsertOrderItem,
  cartItems, type CartItem, type InsertCartItem,
  ComparisonFeature
} from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  // Product operations
  getAllProducts(): Promise<Product[]>;
  getProductById(id: number): Promise<Product | undefined>;
  getProductsByCategory(category: string): Promise<Product[]>;
  
  // Order operations
  createOrder(order: InsertOrder): Promise<Order>;
  getOrderById(id: number): Promise<Order | undefined>;
  
  // Order Item operations
  addOrderItem(item: InsertOrderItem): Promise<OrderItem>;
  getOrderItemsByOrderId(orderId: number): Promise<OrderItem[]>;
  
  // Cart operations
  getCartItemsBySessionId(sessionId: string): Promise<CartItem[]>;
  addCartItem(item: InsertCartItem): Promise<CartItem>;
  updateCartItemQuantity(id: number, quantity: number): Promise<CartItem | undefined>;
  removeCartItem(id: number): Promise<boolean>;
  clearCart(sessionId: string): Promise<boolean>;
  
  // Comparison features
  getComparisonFeatures(): Promise<ComparisonFeature[]>;
}

export class MemStorage implements IStorage {
  private products: Map<number, Product>;
  private orders: Map<number, Order>;
  private orderItems: Map<number, OrderItem>;
  private cartItems: Map<number, CartItem>;
  private comparisonFeatures: ComparisonFeature[];
  
  private productIdCounter: number;
  private orderIdCounter: number;
  private orderItemIdCounter: number;
  private cartItemIdCounter: number;
  
  constructor() {
    this.products = new Map();
    this.orders = new Map();
    this.orderItems = new Map();
    this.cartItems = new Map();
    
    this.productIdCounter = 1;
    this.orderIdCounter = 1;
    this.orderItemIdCounter = 1;
    this.cartItemIdCounter = 1;
    
    // Initialize with sample data
    this.initializeData();
  }
  
  // Product operations
  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }
  
  async getProductById(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }
  
  async getProductsByCategory(category: string): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      product => product.category === category
    );
  }
  
  // Order operations
  async createOrder(order: InsertOrder): Promise<Order> {
    const id = this.orderIdCounter++;
    const newOrder: Order = { ...order, id, createdAt: new Date() };
    this.orders.set(id, newOrder);
    return newOrder;
  }
  
  async getOrderById(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }
  
  // Order Item operations
  async addOrderItem(item: InsertOrderItem): Promise<OrderItem> {
    const id = this.orderItemIdCounter++;
    const newItem: OrderItem = { ...item, id };
    this.orderItems.set(id, newItem);
    return newItem;
  }
  
  async getOrderItemsByOrderId(orderId: number): Promise<OrderItem[]> {
    return Array.from(this.orderItems.values()).filter(
      item => item.orderId === orderId
    );
  }
  
  // Cart operations
  async getCartItemsBySessionId(sessionId: string): Promise<CartItem[]> {
    return Array.from(this.cartItems.values()).filter(
      item => item.sessionId === sessionId
    );
  }
  
  async addCartItem(item: InsertCartItem): Promise<CartItem> {
    const id = this.cartItemIdCounter++;
    const newItem: CartItem = { ...item, id };
    this.cartItems.set(id, newItem);
    return newItem;
  }
  
  async updateCartItemQuantity(id: number, quantity: number): Promise<CartItem | undefined> {
    const item = this.cartItems.get(id);
    if (!item) return undefined;
    
    const updatedItem = { ...item, quantity };
    this.cartItems.set(id, updatedItem);
    return updatedItem;
  }
  
  async removeCartItem(id: number): Promise<boolean> {
    return this.cartItems.delete(id);
  }
  
  async clearCart(sessionId: string): Promise<boolean> {
    const itemsToRemove = Array.from(this.cartItems.values())
      .filter(item => item.sessionId === sessionId)
      .map(item => item.id);
    
    itemsToRemove.forEach(id => this.cartItems.delete(id));
    return true;
  }
  
  // Comparison features
  async getComparisonFeatures(): Promise<ComparisonFeature[]> {
    return this.comparisonFeatures;
  }
  
  // Initialize with sample data
  private initializeData() {
    // Sample products
    const productsData: InsertProduct[] = [
      {
        name: "Rice Water Cleanser",
        description: "Gentle daily cleanser infused with rice water extracts.",
        price: 1200, // Price in BDT
        category: "Cleanser",
        image: "/assets/products/cleanser.png",
        isNew: false,
        isBestseller: true,
        ingredients: "Aqua, Rice Water Extract, Glycerin, Sodium Cocoyl Isethionate, Cocamidopropyl Betaine, Panthenol, Centella Asiatica Extract, Aloe Vera Leaf Juice, Tocopherol, Citric Acid, Sodium Benzoate, Potassium Sorbate",
        howToUse: "Apply to damp skin, massage gently in circular motions, and rinse thoroughly with warm water. Use morning and evening.",
        benefits: ["Gently cleanses without stripping natural oils", "Soothes and calms irritated skin", "Brightens complexion", "Removes impurities and makeup"],
        sizes: [
          { size: "100ml", price: 1200 },
          { size: "200ml", price: 2000 }
        ]
      },
      {
        name: "Rice Water Toner",
        description: "Balancing toner with fermented rice water.",
        price: 1500, // Price in BDT
        category: "Toner",
        image: "/assets/products/toner.png",
        isNew: false,
        isBestseller: false,
        ingredients: "Fermented Rice Water, Glycerin, Butylene Glycol, Niacinamide, Betaine, Adenosine, Centella Asiatica Extract, Licorice Root Extract, Allantoin, Panthenol, Sodium Hyaluronate, Ethylhexylglycerin, Phenoxyethanol",
        howToUse: "After cleansing, apply to face and neck using gentle patting motions until fully absorbed. Use morning and evening.",
        benefits: ["Balances skin pH", "Hydrates and preps skin for serums", "Reduces appearance of pores", "Brightens and evens skin tone"],
        sizes: [
          { size: "150ml", price: 1500 },
          { size: "250ml", price: 2300 }
        ]
      },
      {
        name: "Rice Water Serum",
        description: "Concentrated serum with rice protein and antioxidants.",
        price: 2800, // Price in BDT
        category: "Serum",
        image: "/assets/products/serum.png",
        isNew: true,
        isBestseller: false,
        ingredients: "Fermented Rice Water Extract, Niacinamide, Hyaluronic Acid, Rice Bran Oil, Centella Asiatica Extract, Licorice Root Extract, Adenosine, Peptides, Sodium Hyaluronate, Butylene Glycol, Glycerin, Tocopherol, Ethylhexylglycerin, Phenoxyethanol",
        howToUse: "After toning, apply 2-3 drops to face and neck using gentle patting motions until fully absorbed. Use morning and evening.",
        benefits: ["Brightens and evens skin tone", "Reduces appearance of fine lines", "Strengthens skin barrier", "Provides deep hydration", "Soothes irritation and redness"],
        sizes: [
          { size: "30ml", price: 2800 },
          { size: "50ml", price: 4200 }
        ]
      },
      {
        name: "Rice Water Moisturizer",
        description: "Hydrating moisturizer with rice bran oil and ceramides.",
        price: 2200, // Price in BDT
        category: "Moisturizer",
        image: "/assets/products/moisturizer.png",
        isNew: false,
        isBestseller: false,
        ingredients: "Aqua, Rice Water Extract, Rice Bran Oil, Ceramides, Glycerin, Shea Butter, Squalane, Niacinamide, Sodium Hyaluronate, Panthenol, Allantoin, Adenosine, Tocopherol, Butylene Glycol, Carbomer, Ethylhexylglycerin, Phenoxyethanol",
        howToUse: "After applying serum, gently massage a small amount onto face and neck until absorbed. Use morning and evening.",
        benefits: ["Deeply hydrates skin", "Strengthens moisture barrier", "Improves skin elasticity", "Soothes and nourishes", "Prevents moisture loss"],
        sizes: [
          { size: "50ml", price: 2200 },
          { size: "100ml", price: 3800 }
        ]
      }
    ];
    
    // Add products to storage
    productsData.forEach(product => {
      const id = this.productIdCounter++;
      this.products.set(id, { ...product, id });
    });
    
    // Comparison features
    this.comparisonFeatures = [
      {
        name: "100% Natural Ingredients",
        skinBliss: true,
        bodyShop: false,
        innisfree: false,
        mamaearth: true,
        ponds: false
      },
      {
        name: "Rice Water Formula",
        skinBliss: true,
        bodyShop: false,
        innisfree: true,
        mamaearth: false,
        ponds: false
      },
      {
        name: "No Artificial Fragrances",
        skinBliss: true,
        bodyShop: false,
        innisfree: false,
        mamaearth: true,
        ponds: false
      },
      {
        name: "Cruelty-Free",
        skinBliss: true,
        bodyShop: true,
        innisfree: false,
        mamaearth: true,
        ponds: false
      },
      {
        name: "Locally Made in Bangladesh",
        skinBliss: true,
        bodyShop: false,
        innisfree: false,
        mamaearth: false,
        ponds: false
      },
      {
        name: "Affordable Premium",
        skinBliss: true,
        bodyShop: false,
        innisfree: false,
        mamaearth: true,
        ponds: true
      }
    ];
  }
}

export const storage = new MemStorage();
