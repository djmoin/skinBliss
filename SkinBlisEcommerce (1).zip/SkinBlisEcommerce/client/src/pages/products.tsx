import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Product } from "@shared/schema";
import ProductCard from "@/components/products/ProductCard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Products() {
  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });
  
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split("?")[1] || "");
  const categoryFilter = searchParams.get("category");
  
  // Reset to top of page on mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  
  const categories = ["All", "Cleanser", "Toner", "Serum", "Moisturizer"];
  
  const filteredProducts = products?.filter(
    (product) => !categoryFilter || categoryFilter === "All" || product.category === categoryFilter
  );

  return (
    <div className="py-12 px-4">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h1 className="font-cormorant text-4xl md:text-5xl font-light mb-4">
            Our <span className="font-semibold">Products</span>
          </h1>
          <p className="max-w-xl mx-auto">
            Discover our collection of premium natural skincare products infused with rice water extracts.
          </p>
        </div>
        
        <Tabs defaultValue={categoryFilter || "All"} className="w-full mb-8">
          <div className="flex justify-center">
            <TabsList className="bg-[#F8E7DD] bg-opacity-30">
              {categories.map((category) => (
                <TabsTrigger 
                  key={category} 
                  value={category}
                  className="data-[state=active]:bg-[#94B7B3] data-[state=active]:text-white"
                >
                  {category}
                </TabsTrigger>
              ))}
            </TabsList>
          </div>
        </Tabs>
        
        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#94B7B3]"></div>
          </div>
        ) : filteredProducts && filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-lg">No products found in this category.</p>
          </div>
        )}
      </div>
    </div>
  );
}
