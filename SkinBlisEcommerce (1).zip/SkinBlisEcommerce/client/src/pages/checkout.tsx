import { useState, useEffect } from "react";
import { useLocation, useRoute } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useCart } from "@/context/CartContext";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { insertOrderSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

// Extend the order schema for form validation
const checkoutFormSchema = insertOrderSchema.extend({
  confirmEmail: z.string().email(),
  cardNumber: z.string().min(16, "Card number must be at least 16 digits"),
  cardExpiry: z.string().min(5, "Please enter a valid expiration date (MM/YY)"),
  cardCvc: z.string().min(3, "CVC must be at least 3 digits"),
}).refine((data) => data.customerEmail === data.confirmEmail, {
  message: "Emails do not match",
  path: ["confirmEmail"],
});

type CheckoutFormValues = z.infer<typeof checkoutFormSchema>;

export default function Checkout() {
  const { cartItems, clearCart } = useCart();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [cartTotal, setCartTotal] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const form = useForm<CheckoutFormValues>({
    resolver: zodResolver(checkoutFormSchema),
    defaultValues: {
      customerName: "",
      customerEmail: "",
      confirmEmail: "",
      customerPhone: "",
      shippingAddress: "",
      totalPrice: 0,
      status: "pending",
      cardNumber: "",
      cardExpiry: "",
      cardCvc: "",
    },
  });
  
  useEffect(() => {
    window.scrollTo(0, 0);
    
    // Calculate cart total
    const total = cartItems.reduce((sum, item) => {
      const itemPrice = item.product?.sizes.find(s => s.size === item.size)?.price || 0;
      return sum + (itemPrice * item.quantity);
    }, 0);
    
    // Add shipping cost if below free shipping threshold
    const finalTotal = total >= 3000 ? total : total + 150;
    setCartTotal(finalTotal);
    
    // Set the total price in the form
    form.setValue("totalPrice", finalTotal);
    
    // Redirect to cart if empty
    if (cartItems.length === 0) {
      toast({
        title: "Your cart is empty",
        description: "Please add some products to your cart before checking out.",
        variant: "destructive",
      });
      navigate("/cart");
    }
  }, [cartItems, form, navigate, toast]);
  
  const onSubmit = async (data: CheckoutFormValues) => {
    try {
      setIsSubmitting(true);
      
      // Create order
      const orderResponse = await apiRequest("POST", "/api/orders", {
        customerName: data.customerName,
        customerEmail: data.customerEmail,
        customerPhone: data.customerPhone,
        shippingAddress: data.shippingAddress,
        totalPrice: cartTotal,
        status: "pending"
      });
      
      const order = await orderResponse.json();
      
      // Add order items for each cart item
      for (const item of cartItems) {
        const itemPrice = item.product?.sizes.find(s => s.size === item.size)?.price || 0;
        
        await apiRequest("POST", `/api/orders/${order.id}/items`, {
          productId: item.productId,
          quantity: item.quantity,
          size: item.size,
          price: itemPrice
        });
      }
      
      // Clear the cart
      clearCart();
      
      toast({
        title: "Order placed successfully!",
        description: `Your order #${order.id} has been received.`,
      });
      
      // Navigate to confirmation page or home
      navigate("/");
    } catch (error) {
      toast({
        title: "Failed to place order",
        description: "There was an error processing your order. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="font-cormorant text-3xl md:text-4xl font-semibold mb-8 text-center">Checkout</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <Card className="mb-8">
                <CardHeader>
                  <CardTitle>Contact Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <FormField
                    control={form.control}
                    name="customerName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Full Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter your full name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="customerEmail"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Address</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your email" type="email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="confirmEmail"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Confirm Email</FormLabel>
                          <FormControl>
                            <Input placeholder="Confirm your email" type="email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="customerPhone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone Number</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter your phone number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>
              
              <Card className="mb-8">
                <CardHeader>
                  <CardTitle>Shipping Information</CardTitle>
                </CardHeader>
                <CardContent>
                  <FormField
                    control={form.control}
                    name="shippingAddress"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Complete Address</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter your complete address" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>
              
              <Card className="mb-8">
                <CardHeader>
                  <CardTitle>Payment Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <FormField
                    control={form.control}
                    name="cardNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Card Number</FormLabel>
                        <FormControl>
                          <Input placeholder="1234 5678 9012 3456" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="cardExpiry"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Expiration Date</FormLabel>
                          <FormControl>
                            <Input placeholder="MM/YY" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="cardCvc"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>CVC</FormLabel>
                          <FormControl>
                            <Input placeholder="123" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button 
                    type="submit" 
                    className="w-full bg-[#94B7B3] hover:bg-opacity-90"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <div className="flex items-center">
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                        Processing...
                      </div>
                    ) : (
                      "Place Order"
                    )}
                  </Button>
                </CardFooter>
              </Card>
            </form>
          </Form>
        </div>
        
        <div>
          <Card className="sticky top-20">
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {cartItems.map((item) => (
                  <div key={item.id} className="flex justify-between pb-2">
                    <div>
                      <p className="font-medium">{item.product?.name}</p>
                      <p className="text-sm text-gray-500">
                        {item.size} × {item.quantity}
                      </p>
                    </div>
                    <p className="font-medium">
                      {item.product?.sizes.find(s => s.size === item.size)?.price * item.quantity} BDT
                    </p>
                  </div>
                ))}
                
                <Separator />
                
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>
                    {cartItems.reduce((sum, item) => {
                      const itemPrice = item.product?.sizes.find(s => s.size === item.size)?.price || 0;
                      return sum + (itemPrice * item.quantity);
                    }, 0)} BDT
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Shipping</span>
                  <span>
                    {cartTotal >= 3000 ? 'Free' : '150 BDT'}
                  </span>
                </div>
                <Separator />
                <div className="flex justify-between font-semibold text-lg pt-2">
                  <span>Total</span>
                  <span>{cartTotal} BDT</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
