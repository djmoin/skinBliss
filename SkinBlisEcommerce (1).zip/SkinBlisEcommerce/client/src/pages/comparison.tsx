import { useEffect } from "react";
import ComparisonTable from "@/components/products/ComparisonTable";

export default function Comparison() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="py-16 px-4 bg-[#F8E7DD] bg-opacity-30">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h1 className="font-cormorant text-3xl md:text-4xl font-light mb-4">
            Why Choose <span className="font-semibold">SkinBliss</span>
          </h1>
          <p className="max-w-xl mx-auto text-sm md:text-base">
            See how our natural rice water formulations compare to other popular skincare brands.
          </p>
        </div>
        
        <ComparisonTable />
        
        <div className="mt-16 max-w-3xl mx-auto">
          <h2 className="font-cormorant text-2xl md:text-3xl font-light mb-4 text-center">
            The <span className="font-semibold">SkinBliss</span> Difference
          </h2>
          
          <div className="bg-white p-8 rounded-lg shadow-sm mt-8">
            <h3 className="font-cormorant text-xl font-semibold mb-4">Rice Water: A Time-Tested Beauty Secret</h3>
            <p className="mb-4">
              For centuries, women across Asia have been using rice water as a beauty treatment for their skin and hair. This tradition dates back to ancient Japan, where court ladies were known for their beautiful long hair, which they attributed to washing with rice water.
            </p>
            <p className="mb-4">
              Rice water is packed with vitamins, minerals, and amino acids that nourish and brighten the skin. It contains inositol, a carbohydrate that helps repair damaged skin and promotes cell growth. The starch in rice water also has soothing properties that can help with skin irritation and inflammation.
            </p>
            
            <h3 className="font-cormorant text-xl font-semibold mb-4 mt-8">Our Commitment to Quality</h3>
            <p className="mb-4">
              At SkinBliss, we're dedicated to creating the highest quality natural skincare products. We source our ingredients from trusted suppliers and each product undergoes rigorous testing to ensure safety and efficacy.
            </p>
            <p className="mb-4">
              Unlike many brands that use rice water as a marketing gimmick with minimal concentration, our formulations contain a high percentage of fermented rice water extract, ensuring you receive the full benefits of this remarkable ingredient.
            </p>
            
            <h3 className="font-cormorant text-xl font-semibold mb-4 mt-8">Proudly Made in Bangladesh</h3>
            <p>
              SkinBliss is proud to be a locally made brand that celebrates the beauty traditions of Bangladesh while incorporating modern skincare science. By choosing SkinBliss, you're not only benefiting your skin but also supporting local artisans and sustainable practices.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
