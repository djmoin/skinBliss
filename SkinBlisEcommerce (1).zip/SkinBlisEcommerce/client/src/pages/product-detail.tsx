import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Product } from "@shared/schema";
import { useCart } from "@/context/CartContext";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import ProductGallery from "@/components/products/ProductGallery";
import ProductTabs from "@/components/products/ProductTabs";
import QuantitySizeSelector from "@/components/products/QuantitySizeSelector";
import { Heart } from "lucide-react";

export default function ProductDetail() {
  const [, params] = useRoute("/product/:id");
  const productId = params?.id ? parseInt(params.id) : 0;
  
  const { data: product, isLoading, isError } = useQuery<Product>({
    queryKey: [`/api/products/${productId}`],
    enabled: !!productId,
  });
  
  const { addToCart } = useCart();
  const { toast } = useToast();
  
  const [quantity, setQuantity] = useState(1);
  const [selectedSize, setSelectedSize] = useState("");
  
  useEffect(() => {
    // Reset to top of page on mount
    window.scrollTo(0, 0);
    
    // Set default size when product data is loaded
    if (product && product.sizes.length > 0) {
      setSelectedSize(product.sizes[0].size);
    }
  }, [product]);
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#94B7B3]"></div>
      </div>
    );
  }
  
  if (isError || !product) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-bold mb-4">Product Not Found</h2>
        <p>The product you are looking for does not exist or has been removed.</p>
      </div>
    );
  }
  
  const handleAddToCart = () => {
    if (!selectedSize) {
      toast({
        title: "Please select a size",
        description: "You must select a size before adding to cart",
        variant: "destructive",
      });
      return;
    }
    
    addToCart({
      productId: product.id,
      quantity,
      size: selectedSize,
      sessionId: "user-session",
      product
    });
    
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
    });
  };
  
  // Find the price for the selected size
  const selectedSizePrice = product.sizes.find(s => s.size === selectedSize)?.price || product.price;
  const totalPrice = selectedSizePrice * quantity;

  return (
    <section className="py-16 px-4 bg-[#F8E7DD] bg-opacity-30">
      <div className="container mx-auto">
        <div className="flex flex-col lg:flex-row">
          <ProductGallery product={product} />
          
          <div className="lg:w-1/2">
            <div className="mb-4">
              <h2 className="font-cormorant text-3xl md:text-4xl font-semibold mb-2">{product.name}</h2>
              <div className="flex items-center mb-4">
                <div className="flex text-[#D4AF37]">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star-half-alt"></i>
                </div>
                <span className="text-sm ml-2">4.7 (124 reviews)</span>
              </div>
              <p className="text-2xl font-medium mb-4">{totalPrice} BDT</p>
              <p className="mb-6">{product.description}</p>
            </div>
            
            <div className="mb-6">
              <QuantitySizeSelector
                product={product}
                onQuantityChange={setQuantity}
                onSizeChange={setSelectedSize}
                initialQuantity={quantity}
                initialSize={selectedSize}
              />
              
              <div className="flex space-x-4 mb-6">
                <Button 
                  className="flex-1 bg-[#94B7B3] text-white hover:bg-opacity-90"
                  onClick={handleAddToCart}
                >
                  Add to Cart
                </Button>
                <Button 
                  variant="outline" 
                  size="icon" 
                  className="w-12 h-12 flex items-center justify-center border-[#94B7B3] text-[#94B7B3] hover:bg-[#94B7B3] hover:text-white"
                >
                  <Heart size={20} />
                </Button>
              </div>
              
              <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
                <div className="flex items-center space-x-3 mb-3">
                  <div className="w-10 h-10 rounded-full bg-[#94B7B3] flex items-center justify-center">
                    <i className="fas fa-truck text-white text-sm"></i>
                  </div>
                  <div>
                    <p className="font-medium">Free shipping</p>
                    <p className="text-sm">On orders over 3000 BDT</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-full bg-[#94B7B3] flex items-center justify-center">
                    <i className="fas fa-undo text-white text-sm"></i>
                  </div>
                  <div>
                    <p className="font-medium">Easy returns</p>
                    <p className="text-sm">30-day return policy</p>
                  </div>
                </div>
              </div>
            </div>
            
            <ProductTabs product={product} />
          </div>
        </div>
      </div>
    </section>
  );
}
