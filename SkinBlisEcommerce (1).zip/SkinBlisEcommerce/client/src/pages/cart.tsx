import { useEffect, useState } from "react";
import { Link } from "wouter";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";

export default function Cart() {
  const { cartItems, updateCartItem, removeCartItem, clearCart } = useCart();
  const [cartTotal, setCartTotal] = useState(0);
  
  useEffect(() => {
    window.scrollTo(0, 0);
    
    // Calculate cart total
    const total = cartItems.reduce((sum, item) => {
      const itemPrice = item.product?.sizes.find(s => s.size === item.size)?.price || 0;
      return sum + (itemPrice * item.quantity);
    }, 0);
    setCartTotal(total);
  }, [cartItems]);
  
  const handleQuantityChange = (id: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    updateCartItem(id, newQuantity);
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="font-cormorant text-3xl md:text-4xl font-semibold mb-8 text-center">Your Shopping Cart</h1>
      
      {cartItems.length === 0 ? (
        <div className="text-center py-12">
          <div className="w-20 h-20 bg-[#F8E7DD] rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="fas fa-shopping-bag text-[#94B7B3] text-2xl"></i>
          </div>
          <h2 className="text-xl mb-4">Your cart is empty</h2>
          <p className="mb-6 text-gray-600">Looks like you haven't added any products to your cart yet.</p>
          <Link href="/products">
            <Button className="bg-[#94B7B3] hover:bg-opacity-90">
              Browse Products
            </Button>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Cart Items</CardTitle>
              </CardHeader>
              <CardContent>
                {cartItems.map((item) => (
                  <div key={item.id} className="flex py-4 border-b last:border-0">
                    <div className="w-24 h-24 bg-gray-100 rounded overflow-hidden">
                      {item.product && (
                        <img 
                          src={item.product.image} 
                          alt={item.product.name} 
                          className="w-full h-full object-cover"
                        />
                      )}
                    </div>
                    <div className="ml-4 flex-1">
                      <div className="flex justify-between">
                        <Link href={`/product/${item.productId}`}>
                          <h3 className="font-medium hover:text-[#94B7B3]">{item.product?.name}</h3>
                        </Link>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-gray-400 hover:text-red-500 h-6 w-6"
                          onClick={() => removeCartItem(item.id)}
                        >
                          <i className="fas fa-times"></i>
                        </Button>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">Size: {item.size}</p>
                      <div className="flex justify-between items-center">
                        <div className="flex items-center border rounded">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8 p-0"
                            onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                          >
                            <i className="fas fa-minus text-xs"></i>
                          </Button>
                          <span className="px-3">{item.quantity}</span>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8 p-0"
                            onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                          >
                            <i className="fas fa-plus text-xs"></i>
                          </Button>
                        </div>
                        <p className="font-medium">
                          {item.product?.sizes.find(s => s.size === item.size)?.price * item.quantity} BDT
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button 
                  variant="outline" 
                  onClick={clearCart}
                >
                  Clear Cart
                </Button>
                <Link href="/products">
                  <Button variant="ghost">
                    Continue Shopping
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
          
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>{cartTotal} BDT</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Shipping</span>
                    <span>{cartTotal >= 3000 ? 'Free' : '150 BDT'}</span>
                  </div>
                  <div className="pt-4">
                    <Input placeholder="Enter coupon code" className="mb-2" />
                    <Button variant="outline" className="w-full">Apply Coupon</Button>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-semibold text-lg pt-2">
                    <span>Total</span>
                    <span>{cartTotal >= 3000 ? cartTotal : cartTotal + 150} BDT</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Link href="/checkout" className="w-full">
                  <Button className="w-full bg-[#94B7B3] hover:bg-opacity-90">
                    Proceed to Checkout
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}
