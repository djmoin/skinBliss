import logo from './logo.svg';
import logoFull from './logo-full.png';
import moisturizer from './products/moisturizer.png';
import toner from './products/toner.png';
import serum from './products/serum.png';
import cleanser from './products/cleanser.png';

export {
  logo,
  logoFull,
  moisturizer,
  toner,
  serum,
  cleanser
};