import React, { createContext, useContext, useState, useEffect } from "react";
import { CartItem, Product } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

interface CartItemWithProduct extends CartItem {
  product?: Product;
}

interface CartContextType {
  cartItems: CartItemWithProduct[];
  isCartOpen: boolean;
  addToCart: (item: CartItemWithProduct) => void;
  updateCartItem: (id: number, quantity: number) => void;
  removeCartItem: (id: number) => void;
  clearCart: () => void;
  toggleCart: () => void;
}

const CartContext = createContext<CartContextType>({
  cartItems: [],
  isCartOpen: false,
  addToCart: () => {},
  updateCartItem: () => {},
  removeCartItem: () => {},
  clearCart: () => {},
  toggleCart: () => {},
});

export const useCart = () => useContext(CartContext);

interface CartProviderProps {
  children: React.ReactNode;
}

export const CartProvider: React.FC<CartProviderProps> = ({ children }) => {
  const [cartItems, setCartItems] = useState<CartItemWithProduct[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Session ID for cart (in a real app, this would come from authentication)
  const sessionId = "user-session";

  // Load cart items from local storage on mount
  useEffect(() => {
    const savedCart = localStorage.getItem("cart");
    if (savedCart) {
      try {
        setCartItems(JSON.parse(savedCart));
      } catch (error) {
        console.error("Failed to parse cart from localStorage:", error);
      }
    }
  }, []);

  // Save cart items to local storage when they change
  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cartItems));
  }, [cartItems]);

  const addToCart = async (item: CartItemWithProduct) => {
    try {
      // Check if item already exists in cart with same size
      const existingItemIndex = cartItems.findIndex(
        (cartItem) => cartItem.productId === item.productId && cartItem.size === item.size
      );

      if (existingItemIndex !== -1) {
        // Update quantity of existing item
        const updatedItems = [...cartItems];
        updatedItems[existingItemIndex].quantity += item.quantity;
        setCartItems(updatedItems);
      } else {
        // In a real implementation, we would call the API to add item to cart
        // For this example, we'll use local state
        // const response = await apiRequest("POST", "/api/cart", { ...item, sessionId });
        // const newCartItem = await response.json();
        // setCartItems([...cartItems, newCartItem]);
        
        // Simulating API response with a new ID
        const newItem = {
          ...item,
          id: Date.now(),
          sessionId
        };
        setCartItems([...cartItems, newItem]);
      }
    } catch (error) {
      console.error("Failed to add item to cart:", error);
    }
  };

  const updateCartItem = async (id: number, quantity: number) => {
    try {
      // In a real implementation, we would call the API to update item quantity
      // For this example, we'll use local state
      // await apiRequest("PUT", `/api/cart/${id}`, { quantity });
      
      const updatedItems = cartItems.map((item) =>
        item.id === id ? { ...item, quantity } : item
      );
      setCartItems(updatedItems);
    } catch (error) {
      console.error("Failed to update cart item:", error);
    }
  };

  const removeCartItem = async (id: number) => {
    try {
      // In a real implementation, we would call the API to remove item
      // For this example, we'll use local state
      // await apiRequest("DELETE", `/api/cart/${id}`);
      
      const updatedItems = cartItems.filter((item) => item.id !== id);
      setCartItems(updatedItems);
    } catch (error) {
      console.error("Failed to remove cart item:", error);
    }
  };

  const clearCart = async () => {
    try {
      // In a real implementation, we would call the API to clear the cart
      // For this example, we'll use local state
      // await apiRequest("DELETE", `/api/cart/session/${sessionId}`);
      
      setCartItems([]);
    } catch (error) {
      console.error("Failed to clear cart:", error);
    }
  };

  const toggleCart = () => {
    setIsCartOpen(!isCartOpen);
  };

  return (
    <CartContext.Provider
      value={{
        cartItems,
        isCartOpen,
        addToCart,
        updateCartItem,
        removeCartItem,
        clearCart,
        toggleCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};
