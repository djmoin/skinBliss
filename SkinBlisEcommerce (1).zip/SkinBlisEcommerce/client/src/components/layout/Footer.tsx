import { Link } from "wouter";

export default function Footer() {
  return (
    <footer id="contact" className="bg-[#2C3E50] text-white pt-12 pb-6 px-4">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <h3 className="font-cormorant text-2xl mb-4">SkinBliss</h3>
            <p className="text-sm text-white text-opacity-80 mb-4">
              Premium natural skincare products powered by the ancient tradition of rice water.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-white hover:text-[#94B7B3] transition-colors">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" className="text-white hover:text-[#94B7B3] transition-colors">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="#" className="text-white hover:text-[#94B7B3] transition-colors">
                <i className="fab fa-youtube"></i>
              </a>
              <a href="#" className="text-white hover:text-[#94B7B3] transition-colors">
                <i className="fab fa-pinterest-p"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-medium mb-4">Shop</h4>
            <ul className="space-y-2 text-sm text-white text-opacity-80">
              <li>
                <Link href="/products" className="hover:text-[#94B7B3] transition-colors">
                  All Products
                </Link>
              </li>
              <li>
                <Link href="/products?category=Moisturizer" className="hover:text-[#94B7B3] transition-colors">
                  Moisturizers
                </Link>
              </li>
              <li>
                <Link href="/products?category=Cleanser" className="hover:text-[#94B7B3] transition-colors">
                  Cleansers
                </Link>
              </li>
              <li>
                <Link href="/products?category=Serum" className="hover:text-[#94B7B3] transition-colors">
                  Serums
                </Link>
              </li>
              <li>
                <Link href="/products?category=Toner" className="hover:text-[#94B7B3] transition-colors">
                  Toners
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-medium mb-4">About</h4>
            <ul className="space-y-2 text-sm text-white text-opacity-80">
              <li>
                <Link href="/#about" className="hover:text-[#94B7B3] transition-colors">
                  Our Story
                </Link>
              </li>
              <li>
                <Link href="/#about" className="hover:text-[#94B7B3] transition-colors">
                  Ingredients
                </Link>
              </li>
              <li>
                <Link href="/comparison" className="hover:text-[#94B7B3] transition-colors">
                  Comparison
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-medium mb-4">Help</h4>
            <ul className="space-y-2 text-sm text-white text-opacity-80">
              <li>
                <Link href="#contact" className="hover:text-[#94B7B3] transition-colors">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-[#94B7B3] transition-colors">
                  FAQ
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-[#94B7B3] transition-colors">
                  Shipping
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-[#94B7B3] transition-colors">
                  Returns
                </Link>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-white border-opacity-20 pt-6 text-sm text-white text-opacity-60">
          <div className="flex flex-col md:flex-row justify-between">
            <p>&copy; 2023 SkinBliss Natural Skincare. All rights reserved.</p>
            <div className="flex space-x-4 mt-4 md:mt-0">
              <Link href="#" className="hover:text-[#94B7B3] transition-colors">
                Privacy Policy
              </Link>
              <Link href="#" className="hover:text-[#94B7B3] transition-colors">
                Terms of Service
              </Link>
              <Link href="#" className="hover:text-[#94B7B3] transition-colors">
                Cookie Policy
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
