import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { cleanser, moisturizer, serum, toner } from "@/assets";

export default function CartDrawer() {
  const { cartItems, isCartOpen, toggleCart, updateCartItem, removeCartItem, clearCart } = useCart();
  const [location] = useLocation();
  const { toast } = useToast();
  const [cartTotal, setCartTotal] = useState(0);

  useEffect(() => {
    // Calculate cart total
    const total = cartItems.reduce((sum, item) => {
      const itemPrice = item.product?.sizes.find(s => s.size === item.size)?.price || 0;
      return sum + (itemPrice * item.quantity);
    }, 0);
    setCartTotal(total);
  }, [cartItems]);

  useEffect(() => {
    // Close cart when location changes
    if (isCartOpen) {
      toggleCart();
    }
  }, [location]);

  const handleQuantityChange = (id: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    updateCartItem(id, newQuantity);
  };

  const handleRemoveItem = (id: number) => {
    removeCartItem(id);
    toast({
      title: "Item removed",
      description: "The item has been removed from your cart.",
    });
  };

  const handleCheckout = () => {
    if (cartItems.length === 0) {
      toast({
        title: "Cart is empty",
        description: "Please add items to your cart before checking out.",
        variant: "destructive",
      });
      return;
    }
  };

  // Helper function to get the correct image based on product category
  const getProductImage = (category?: string) => {
    if (!category) return '';
    
    switch(category.toLowerCase()) {
      case 'cleanser':
        return cleanser;
      case 'toner':
        return toner;
      case 'serum':
        return serum;
      case 'moisturizer':
        return moisturizer;
      default:
        return '';
    }
  };

  return (
    <>
      {/* Overlay */}
      {isCartOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40" 
          onClick={toggleCart}
        ></div>
      )}
      
      {/* Cart Drawer */}
      <div className={`fixed inset-y-0 right-0 w-full md:w-96 bg-white shadow-xl transform ${isCartOpen ? 'translate-x-0' : 'translate-x-full'} transition-transform duration-300 ease-in-out z-50 overflow-hidden flex flex-col`}>
        <div className="p-4 border-b flex justify-between items-center">
          <h3 className="font-medium text-lg">Your Cart</h3>
          <Button variant="ghost" size="icon" onClick={toggleCart}>
            <i className="fas fa-times"></i>
          </Button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4">
          {/* Empty cart message */}
          {cartItems.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full">
              <div className="w-16 h-16 bg-[#F8E7DD] rounded-full flex items-center justify-center mb-4">
                <i className="fas fa-shopping-bag text-[#94B7B3] text-xl"></i>
              </div>
              <p className="text-center mb-4">Your cart is empty</p>
              <Button 
                className="bg-[#94B7B3] hover:bg-opacity-90"
                onClick={toggleCart}
              >
                Continue Shopping
              </Button>
            </div>
          ) : (
            <div>
              {cartItems.map((item) => (
                <div key={item.id} className="flex mb-4 pb-4 border-b">
                  <div className="w-20 h-20 bg-gray-100 rounded overflow-hidden">
                    {item.product && (
                      <img 
                        src={getProductImage(item.product.category)} 
                        alt={item.product.name} 
                        className="w-full h-full object-cover"
                      />
                    )}
                  </div>
                  <div className="ml-4 flex-1">
                    <div className="flex justify-between">
                      <h4 className="font-medium">{item.product?.name}</h4>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="text-gray-400 hover:text-red-500 h-6 w-6"
                        onClick={() => handleRemoveItem(item.id)}
                      >
                        <i className="fas fa-trash-alt"></i>
                      </Button>
                    </div>
                    <p className="text-sm text-gray-600">{item.size}</p>
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center border rounded">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 p-0"
                          onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                        >
                          <i className="fas fa-minus text-xs"></i>
                        </Button>
                        <span className="px-2 py-1">{item.quantity}</span>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 p-0"
                          onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                        >
                          <i className="fas fa-plus text-xs"></i>
                        </Button>
                      </div>
                      <p className="font-medium">
                        {item.product?.sizes.find(s => s.size === item.size)?.price * item.quantity} BDT
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        <div className="p-4 border-t">
          <div className="mb-4">
            <div className="flex justify-between mb-2">
              <span>Subtotal</span>
              <span className="font-medium">{cartTotal} BDT</span>
            </div>
            <div className="flex justify-between mb-2">
              <span>Shipping</span>
              <span>{cartTotal >= 3000 ? 'Free' : '150 BDT'}</span>
            </div>
            <Separator className="my-2" />
            <div className="flex justify-between font-medium">
              <span>Total</span>
              <span>{cartTotal >= 3000 ? cartTotal : cartTotal + 150} BDT</span>
            </div>
          </div>
          
          <Link href="/checkout">
            <Button 
              className="w-full bg-[#94B7B3] hover:bg-opacity-90 mb-3"
              onClick={handleCheckout}
            >
              Proceed to Checkout
            </Button>
          </Link>
          <Button 
            variant="outline" 
            className="w-full border-[#94B7B3] text-[#94B7B3] hover:bg-[#94B7B3] hover:text-white"
            onClick={toggleCart}
          >
            Continue Shopping
          </Button>
        </div>
      </div>
    </>
  );
}
