import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { logoFull } from "@/assets";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { cartItems, toggleCart } = useCart();
  const [location] = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 100) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  return (
    <header className={`bg-white z-40 w-full ${isScrolled ? "shadow-sm fixed top-0" : ""}`} id="header">
      <div className="container mx-auto px-4 py-4">
        {/* Announcement */}
        <div className="bg-[#F8E7DD] text-center py-2 px-4 mb-4 rounded">
          <p className="text-sm">Free shipping on orders over 3000 BDT</p>
        </div>
        
        {/* Logo and Navigation */}
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center">
            <img src={logoFull} alt="SkinBliss Logo" className="h-16 w-auto" />
          </Link>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className={`text-sm font-medium hover:text-[#94B7B3] transition-colors ${location === '/' ? 'text-[#94B7B3]' : ''}`}>
              Home
            </Link>
            <Link href="/products" className={`text-sm font-medium hover:text-[#94B7B3] transition-colors ${location === '/products' ? 'text-[#94B7B3]' : ''}`}>
              Products
            </Link>
            <Link href="/#about" className={`text-sm font-medium hover:text-[#94B7B3] transition-colors ${location === '/#about' ? 'text-[#94B7B3]' : ''}`}>
              About
            </Link>
            <Link href="/comparison" className={`text-sm font-medium hover:text-[#94B7B3] transition-colors ${location === '/comparison' ? 'text-[#94B7B3]' : ''}`}>
              Compare
            </Link>
            <Link href="#contact" className="text-sm font-medium hover:text-[#94B7B3] transition-colors">
              Contact
            </Link>
          </nav>
          
          {/* Cart and User */}
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-[#2C3E50] hover:text-[#94B7B3] transition-colors p-1"
                onClick={toggleCart}
              >
                <i className="fas fa-shopping-bag text-xl"></i>
                {cartItems.length > 0 && (
                  <span className="absolute -top-2 -right-2 bg-[#94B7B3] text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                    {cartItems.length}
                  </span>
                )}
              </Button>
            </div>
            <Button variant="ghost" size="sm" className="hidden md:inline-flex text-sm font-medium hover:text-[#94B7B3] transition-colors">
              Account
            </Button>
            <Button 
              variant="ghost"
              size="icon"
              className="md:hidden text-[#2C3E50]"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <i className={`fas ${isMenuOpen ? 'fa-times' : 'fa-bars'} text-xl`}></i>
            </Button>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4">
            <nav className="flex flex-col space-y-4">
              <Link href="/" className="text-sm font-medium hover:text-[#94B7B3] transition-colors">
                Home
              </Link>
              <Link href="/products" className="text-sm font-medium hover:text-[#94B7B3] transition-colors">
                Products
              </Link>
              <Link href="/#about" className="text-sm font-medium hover:text-[#94B7B3] transition-colors">
                About
              </Link>
              <Link href="/comparison" className="text-sm font-medium hover:text-[#94B7B3] transition-colors">
                Compare
              </Link>
              <Link href="#contact" className="text-sm font-medium hover:text-[#94B7B3] transition-colors">
                Contact
              </Link>
              <Link href="#" className="text-sm font-medium hover:text-[#94B7B3] transition-colors">
                Account
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
