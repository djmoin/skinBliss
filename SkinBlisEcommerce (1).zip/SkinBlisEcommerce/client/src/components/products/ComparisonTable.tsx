import { useQuery } from "@tanstack/react-query";
import { ComparisonFeature } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Check, X } from "lucide-react";

export default function ComparisonTable() {
  const { data: features, isLoading } = useQuery<ComparisonFeature[]>({
    queryKey: ["/api/comparison"],
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center p-12">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#94B7B3]"></div>
      </div>
    );
  }

  if (!features || features.length === 0) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-center text-gray-500">No comparison data available</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full bg-white rounded-lg shadow-sm">
        <thead>
          <tr className="border-b">
            <th className="p-4 text-left font-medium">Features</th>
            <th className="p-4 text-center bg-[#94B7B3] bg-opacity-10 font-medium">SkinBliss</th>
            <th className="p-4 text-center font-medium">The Body Shop</th>
            <th className="p-4 text-center font-medium">Innisfree</th>
            <th className="p-4 text-center font-medium">Mamaearth</th>
            <th className="p-4 text-center font-medium">Pond's</th>
          </tr>
        </thead>
        <tbody>
          {features.map((feature, index) => (
            <tr key={index} className={index < features.length - 1 ? "border-b" : ""}>
              <td className="p-4 font-medium text-sm">{feature.name}</td>
              <td className="p-4 text-center bg-[#94B7B3] bg-opacity-10">
                {feature.skinBliss ? (
                  <Check className="mx-auto text-[#94B7B3]" size={18} />
                ) : (
                  <X className="mx-auto text-red-400" size={18} />
                )}
              </td>
              <td className="p-4 text-center">
                {feature.bodyShop ? (
                  <Check className="mx-auto text-[#94B7B3]" size={18} />
                ) : (
                  <X className="mx-auto text-red-400" size={18} />
                )}
              </td>
              <td className="p-4 text-center">
                {feature.innisfree ? (
                  <Check className="mx-auto text-[#94B7B3]" size={18} />
                ) : (
                  <X className="mx-auto text-red-400" size={18} />
                )}
              </td>
              <td className="p-4 text-center">
                {feature.mamaearth ? (
                  <Check className="mx-auto text-[#94B7B3]" size={18} />
                ) : (
                  <X className="mx-auto text-red-400" size={18} />
                )}
              </td>
              <td className="p-4 text-center">
                {feature.ponds ? (
                  <Check className="mx-auto text-[#94B7B3]" size={18} />
                ) : (
                  <X className="mx-auto text-red-400" size={18} />
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
