import { useState } from "react";
import { Product } from "@shared/schema";
import { cleanser, moisturizer, serum, toner } from "@/assets";

interface ProductGalleryProps {
  product: Product;
}

export default function ProductGallery({ product }: ProductGalleryProps) {
  // Helper function to get the correct image based on product category
  const getProductImage = () => {
    switch(product.category.toLowerCase()) {
      case 'cleanser':
        return cleanser;
      case 'toner':
        return toner;
      case 'serum':
        return serum;
      case 'moisturizer':
        return moisturizer;
      default:
        return product.image; // fallback to the path from API
    }
  };
  
  const productImage = getProductImage();
  const [mainImage, setMainImage] = useState(productImage);
  
  // In a real app, we would have multiple images per product
  // For now, we'll use the same image for all thumbnails
  const thumbnails = [
    productImage,
    productImage,
    productImage,
    productImage
  ];

  return (
    <div className="lg:w-1/2 lg:pr-12 mb-10 lg:mb-0">
      <div className="bg-white p-8 rounded-lg shadow-sm">
        <img 
          src={mainImage} 
          alt={product.name} 
          className="w-full rounded-lg"
        />
        
        <div className="grid grid-cols-4 gap-4 mt-4">
          {thumbnails.map((thumbnail, index) => (
            <div 
              key={index}
              className={`cursor-pointer border-2 ${mainImage === thumbnail ? 'border-[#94B7B3]' : 'border-transparent'} hover:border-[#94B7B3] rounded-lg overflow-hidden`}
              onClick={() => setMainImage(thumbnail)}
            >
              <img 
                src={thumbnail} 
                alt={`${product.name} view ${index + 1}`} 
                className="w-full h-20 object-cover"
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
