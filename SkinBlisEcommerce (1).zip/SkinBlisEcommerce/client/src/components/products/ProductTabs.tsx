import { useState } from "react";
import { Product } from "@shared/schema";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface ProductTabsProps {
  product: Product;
}

export default function ProductTabs({ product }: ProductTabsProps) {
  return (
    <Tabs defaultValue="description" className="w-full">
      <TabsList className="border-b border-gray-200 w-full justify-start space-x-8 rounded-none bg-transparent">
        <TabsTrigger 
          value="description" 
          className="data-[state=active]:border-b-2 data-[state=active]:border-[#94B7B3] data-[state=active]:text-[#2C3E50] bg-transparent rounded-none px-0 py-2"
        >
          Description
        </TabsTrigger>
        <TabsTrigger 
          value="ingredients" 
          className="data-[state=active]:border-b-2 data-[state=active]:border-[#94B7B3] data-[state=active]:text-[#2C3E50] bg-transparent rounded-none px-0 py-2"
        >
          Ingredients
        </TabsTrigger>
        <TabsTrigger 
          value="how-to-use" 
          className="data-[state=active]:border-b-2 data-[state=active]:border-[#94B7B3] data-[state=active]:text-[#2C3E50] bg-transparent rounded-none px-0 py-2"
        >
          How to Use
        </TabsTrigger>
      </TabsList>
      
      <TabsContent value="description" className="mt-4 pt-2">
        <p className="mb-4">
          Our {product.name} is inspired by the centuries-old Asian beauty ritual of using rice water to achieve radiant, youthful skin. We've enhanced this traditional formula with modern skincare science to create a potent product that:
        </p>
        <ul className="list-disc pl-5 mb-4 space-y-1 text-sm">
          {product.benefits.map((benefit, index) => (
            <li key={index}>{benefit}</li>
          ))}
        </ul>
        <p>Perfect for all skin types, particularly effective for dull, uneven, or aging skin.</p>
      </TabsContent>
      
      <TabsContent value="ingredients" className="mt-4 pt-2">
        <p className="mb-4">Our carefully selected ingredients combine traditional wisdom with modern skincare science:</p>
        <p className="mb-4 whitespace-pre-line">{product.ingredients}</p>
        <p className="mt-4 text-sm italic">Free from parabens, sulfates, phthalates, and artificial fragrances. Not tested on animals.</p>
      </TabsContent>
      
      <TabsContent value="how-to-use" className="mt-4 pt-2">
        <p className="mb-4">For best results, follow these steps:</p>
        <p className="mb-4 whitespace-pre-line">{product.howToUse}</p>
        <p className="mt-4 text-sm">Use morning and evening for optimal results. For daytime use, always follow with sunscreen.</p>
      </TabsContent>
    </Tabs>
  );
}
