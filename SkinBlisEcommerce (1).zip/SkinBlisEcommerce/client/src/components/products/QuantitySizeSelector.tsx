import { useState } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Product } from "@shared/schema";

interface QuantitySizeSelectorProps {
  product: Product;
  onQuantityChange: (quantity: number) => void;
  onSizeChange: (size: string) => void;
  initialQuantity?: number;
  initialSize?: string;
}

export default function QuantitySizeSelector({
  product,
  onQuantityChange,
  onSizeChange,
  initialQuantity = 1,
  initialSize = "",
}: QuantitySizeSelectorProps) {
  const [quantity, setQuantity] = useState(initialQuantity);
  const [selectedSize, setSelectedSize] = useState(initialSize || product.sizes[0].size);

  const handleQuantityChange = (value: string) => {
    const newQuantity = parseInt(value);
    setQuantity(newQuantity);
    onQuantityChange(newQuantity);
  };

  const handleSizeChange = (value: string) => {
    setSelectedSize(value);
    onSizeChange(value);
  };

  return (
    <div className="flex items-center space-x-4 mb-4">
      <div className="w-24">
        <label htmlFor="quantity" className="block text-sm font-medium mb-1">
          Quantity
        </label>
        <Select
          value={quantity.toString()}
          onValueChange={handleQuantityChange}
        >
          <SelectTrigger id="quantity" className="w-full border border-gray-300 rounded focus:ring-2 focus:ring-[#94B7B3]">
            <SelectValue placeholder="Quantity" />
          </SelectTrigger>
          <SelectContent>
            {[1, 2, 3, 4, 5].map((value) => (
              <SelectItem key={value} value={value.toString()}>
                {value}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      <div className="flex-1">
        <label htmlFor="size" className="block text-sm font-medium mb-1">
          Size
        </label>
        <Select
          value={selectedSize}
          onValueChange={handleSizeChange}
        >
          <SelectTrigger id="size" className="w-full border border-gray-300 rounded focus:ring-2 focus:ring-[#94B7B3]">
            <SelectValue placeholder="Select size" />
          </SelectTrigger>
          <SelectContent>
            {product.sizes.map((sizeOption) => (
              <SelectItem key={sizeOption.size} value={sizeOption.size}>
                {sizeOption.size} {sizeOption !== product.sizes[0] && `(+${sizeOption.price - product.sizes[0].price} BDT)`}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}
