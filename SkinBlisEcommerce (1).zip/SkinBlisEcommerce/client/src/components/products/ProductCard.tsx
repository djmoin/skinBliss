import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { useCart } from "@/context/CartContext";
import { useToast } from "@/hooks/use-toast";
import { Product } from "@shared/schema";
import { cleanser, moisturizer, serum, toner } from "@/assets";

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useCart();
  const { toast } = useToast();

  const handleAddToCart = () => {
    // Add first size option by default
    const defaultSize = product.sizes[0]?.size || "";
    
    addToCart({
      productId: product.id,
      quantity: 1,
      size: defaultSize,
      sessionId: "user-session",
      product
    });

    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
    });
  };

  // Helper function to get the correct image based on product category
  const getProductImage = () => {
    switch(product.category.toLowerCase()) {
      case 'cleanser':
        return cleanser;
      case 'toner':
        return toner;
      case 'serum':
        return serum;
      case 'moisturizer':
        return moisturizer;
      default:
        return product.image; // fallback to the path from API
    }
  };

  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-md hover:-translate-y-1">
      <Link href={`/product/${product.id}`}>
        <div className="relative overflow-hidden">
          <img 
            src={getProductImage()} 
            alt={product.name} 
            className="w-full h-64 object-cover transition-transform duration-500 hover:scale-103"
          />
          {product.isNew && (
            <div className="absolute top-3 right-3 bg-[#D4AF37] text-white text-xs py-1 px-3 rounded-full">
              New
            </div>
          )}
          {product.isBestseller && (
            <div className="absolute top-3 right-3 bg-[#94B7B3] text-white text-xs py-1 px-3 rounded-full">
              Bestseller
            </div>
          )}
        </div>
      </Link>
      <CardContent className="p-5">
        <Link href={`/product/${product.id}`}>
          <h3 className="font-cormorant text-xl font-semibold mb-2">{product.name}</h3>
        </Link>
        <p className="text-sm mb-4">{product.description}</p>
        <div className="flex items-center justify-between">
          <span className="font-medium">{product.price} BDT</span>
          <Button 
            className="bg-[#94B7B3] text-white hover:bg-opacity-90"
            onClick={handleAddToCart}
          >
            Add to Cart
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
