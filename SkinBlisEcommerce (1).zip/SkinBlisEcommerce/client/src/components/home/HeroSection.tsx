import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function HeroSection() {
  return (
    <section className="bg-gradient-to-r from-[#F8E7DD] to-white py-20 px-4">
      <div className="container mx-auto flex flex-col lg:flex-row items-center">
        <div className="lg:w-1/2 mb-10 lg:mb-0 lg:pr-10">
          <h1 className="font-cormorant text-4xl md:text-5xl lg:text-6xl font-light mb-4">
            Discover <span className="font-semibold">Natural</span> Skincare
          </h1>
          <h2 className="font-cormorant text-2xl md:text-3xl font-light mb-6">
            Powered by rice water extracts
          </h2>
          <p className="text-sm md:text-base mb-8 max-w-md">
            Experience the transformative benefits of traditional rice water formulations enhanced by modern skincare science. SkinBliss brings you premium natural ingredients for a truly radiant complexion.
          </p>
          <div className="flex space-x-4">
            <Link href="/products">
              <Button className="bg-[#94B7B3] text-white hover:bg-opacity-90">
                Shop Now
              </Button>
            </Link>
            <Link href="/#about">
              <Button variant="outline" className="border-[#94B7B3] text-[#94B7B3] hover:bg-[#94B7B3] hover:text-white">
                Learn More
              </Button>
            </Link>
          </div>
        </div>
        <div className="lg:w-1/2 flex justify-center relative">
          <img 
            src="https://images.unsplash.com/photo-1556228720-195a672f1c52?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
            alt="SkinBliss Collection" 
            className="rounded-lg shadow-xl max-w-full h-auto"
          />
          <div className="absolute -bottom-5 -left-5 bg-white p-3 rounded-lg shadow-lg hidden md:block">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 rounded-full bg-[#94B7B3] flex items-center justify-center">
                <i className="fas fa-leaf text-white"></i>
              </div>
              <div>
                <p className="text-xs font-semibold">100% Natural</p>
                <p className="text-xs">Ethically Sourced</p>
              </div>
            </div>
          </div>
          <div className="absolute -top-5 -right-5 bg-white p-3 rounded-lg shadow-lg hidden md:block">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 rounded-full bg-[#94B7B3] flex items-center justify-center">
                <i className="fas fa-seedling text-white"></i>
              </div>
              <div>
                <p className="text-xs font-semibold">Rice Water</p>
                <p className="text-xs">Premium Formula</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
