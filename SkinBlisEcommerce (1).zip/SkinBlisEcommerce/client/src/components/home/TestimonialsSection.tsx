import TestimonialCard from "@/components/ui/testimonial-card";

export default function TestimonialsSection() {
  const testimonials = [
    {
      rating: 5,
      quote: "I've been using the complete SkinBliss routine for 3 months now and my skin has never looked better! The Rice Water Serum is my absolute favorite - it's made such a difference in my skin's brightness.",
      author: "Sarah K.",
      initial: "S"
    },
    {
      rating: 4.5,
      quote: "As someone with sensitive skin, I've had trouble finding products that don't cause irritation. The SkinBliss Rice Water Cleanser and Moisturizer are so gentle yet effective. My skin feels nourished and calm.",
      author: "Rahima A.",
      initial: "R"
    },
    {
      rating: 5,
      quote: "I love supporting local brands, especially when they create such amazing products! The Rice Water Toner has completely transformed my skin - it's more even-toned and hydrated. Plus, the packaging is beautiful!",
      author: "Tanzila H.",
      initial: "T"
    }
  ];

  return (
    <section className="py-16 px-4 bg-white">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h2 className="font-cormorant text-3xl md:text-4xl font-light mb-4">
            What Our <span className="font-semibold">Customers</span> Say
          </h2>
          <p className="max-w-xl mx-auto text-sm md:text-base">
            Real experiences from real people who have incorporated SkinBliss into their skincare routines.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <TestimonialCard
              key={index}
              rating={testimonial.rating}
              quote={testimonial.quote}
              author={testimonial.author}
              initial={testimonial.initial}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
