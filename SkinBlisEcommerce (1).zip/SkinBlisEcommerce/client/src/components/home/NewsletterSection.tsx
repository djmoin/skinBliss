import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

export default function NewsletterSection() {
  const [email, setEmail] = useState("");
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      toast({
        title: "Email required",
        description: "Please enter your email address.",
        variant: "destructive",
      });
      return;
    }

    // In a real app, we would submit to an API
    toast({
      title: "Thank you for subscribing!",
      description: "You've been added to our newsletter.",
    });
    
    setEmail("");
  };

  return (
    <section className="py-16 px-4 bg-[#94B7B3] bg-opacity-10">
      <div className="container mx-auto max-w-3xl text-center">
        <h2 className="font-cormorant text-3xl md:text-4xl font-light mb-4">
          Join the <span className="font-semibold">SkinBliss</span> Community
        </h2>
        <p className="mb-8">
          Subscribe to our newsletter for exclusive offers, skincare tips, and new product announcements.
        </p>
        
        <form className="flex flex-col md:flex-row gap-4" onSubmit={handleSubmit}>
          <Input
            type="email"
            placeholder="Your email address"
            className="flex-1 px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#94B7B3]"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <Button 
            type="submit" 
            className="bg-[#94B7B3] text-white hover:bg-opacity-90"
          >
            Subscribe
          </Button>
        </form>
        <p className="text-xs mt-4 opacity-70">
          By subscribing, you agree to receive marketing emails from SkinBliss. You can unsubscribe at any time.
        </p>
      </div>
    </section>
  );
}
