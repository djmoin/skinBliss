import BenefitCard from "@/components/ui/benefit-card";

export default function BenefitsSection() {
  const benefits = [
    {
      icon: <i className="fas fa-tint text-white text-xl"></i>,
      title: "Deep Hydration",
      description: "Our rice water formulations contain naturally occurring amino acids and vitamins that penetrate deeply to provide lasting hydration and plumpness."
    },
    {
      icon: <i className="fas fa-sun text-white text-xl"></i>,
      title: "Brightening Power",
      description: "Rice water contains natural compounds that inhibit melanin production, helping to fade dark spots and create a more radiant, even complexion."
    },
    {
      icon: <i className="fas fa-shield-alt text-white text-xl"></i>,
      title: "Barrier Strengthening",
      description: "The proteins and antioxidants in rice water help fortify your skin's natural barrier, protecting against environmental damage and moisture loss."
    },
    {
      icon: <i className="fas fa-leaf text-white text-xl"></i>,
      title: "100% Natural",
      description: "Our formulations use naturally derived ingredients that are gentle on all skin types, even the most sensitive, while delivering powerful results."
    },
    {
      icon: <i className="fas fa-history text-white text-xl"></i>,
      title: "Ancient Wisdom",
      description: "Inspired by centuries-old beauty rituals from Asia, our products harness traditional knowledge that has stood the test of time."
    },
    {
      icon: <i className="fas fa-flask text-white text-xl"></i>,
      title: "Modern Science",
      description: "We enhance traditional formulas with clinically proven ingredients and cutting-edge technologies to maximize efficacy and results."
    }
  ];

  return (
    <section id="about" className="py-16 px-4 bg-white">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h2 className="font-cormorant text-3xl md:text-4xl font-light mb-4">
            The <span className="font-semibold">Rice Water</span> Difference
          </h2>
          <p className="max-w-xl mx-auto text-sm md:text-base">
            Discover why ancient beauty traditions combined with modern science creates the perfect skincare solution.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => (
            <BenefitCard
              key={index}
              icon={benefit.icon}
              title={benefit.title}
              description={benefit.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
