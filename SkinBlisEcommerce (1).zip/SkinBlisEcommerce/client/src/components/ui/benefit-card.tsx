import { LucideIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface BenefitCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

export default function BenefitCard({ icon, title, description }: BenefitCardProps) {
  return (
    <Card className="bg-[#F8E7DD] bg-opacity-20 border-none">
      <CardContent className="p-8 text-center">
        <div className="w-16 h-16 bg-[#94B7B3] rounded-full flex items-center justify-center mx-auto mb-6">
          {icon}
        </div>
        <h3 className="font-cormorant text-xl font-semibold mb-3">{title}</h3>
        <p className="text-sm">{description}</p>
      </CardContent>
    </Card>
  );
}
