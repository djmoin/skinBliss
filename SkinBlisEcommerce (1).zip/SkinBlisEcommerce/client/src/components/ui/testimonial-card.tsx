import { Card, CardContent } from "@/components/ui/card";

interface TestimonialCardProps {
  rating: number;
  quote: string;
  author: string;
  initial: string;
}

export default function TestimonialCard({ rating, quote, author, initial }: TestimonialCardProps) {
  return (
    <Card className="bg-white p-6 shadow-sm border border-gray-100">
      <CardContent className="p-0">
        <div className="flex text-[#D4AF37] mb-4">
          {[...Array(5)].map((_, i) => (
            <i key={i} className={`fas fa-star ${i >= rating ? 'text-gray-300' : ''}`}></i>
          ))}
        </div>
        <p className="italic mb-4">{quote}</p>
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-full bg-[#F8E7DD] flex items-center justify-center">
            <span className="font-medium text-[#94B7B3]">{initial}</span>
          </div>
          <div className="ml-3">
            <p className="font-medium">{author}</p>
            <p className="text-xs">Verified Customer</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
